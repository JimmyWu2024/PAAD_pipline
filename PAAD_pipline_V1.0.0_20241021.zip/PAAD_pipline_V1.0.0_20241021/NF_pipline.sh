#!/bin/bash

help_info()
{
    echo -e "NAME"  
    echo -e "\t$0"  
    echo -e "SYNOPSIS"  
    echo -e "USAGE"  
    echo -e "\tbash $0 -i <> -n <> -o <> -p <> -s <>"
    echo -e "CAUTION"
    echo -e "\tEach of the parmeters above should be provided!\n"
    echo -e "\tIf you have any questions please send email to \n\tzhangqingzheng945@berryoncology.com"  
}


option()
{
    while [ -n "$1" ]
    do
    case "$1" in
    -i)
            echo "Found the -i option"
            Input=$2
            ;;
    -n)
			echo "Found the -n option"
            Name=$2
            ;;
    -o)
            echo "Found the -o option"
            Output=$2
            ;;
    -p)
            echo "Found the -p option"
            Plotdir=$2
            ;;
    -s)
           echo "Found the -s option"
            Softdir=$2
            ;;
     *)
            echo "$1 is not an valid option"
            help_info
            exit -1
            ;;
    esac
    shift 2
    done
}


samtools_code(){
	samtools view -bh -F 1804 -q 20 ${Input} >${Output}${pfx}"/"${pfx}.tmp.bam
	samtools sort -n -@ 5 -m 5G ${Output}${pfx}"/"${pfx}.tmp.bam >${Output}${pfx}"/"${pfx}.sort.bam
}

Getvalue(){
	/subread-1.6.2-source/bin/featureCounts -T 10 -Q 20 -O -p -a ${Softdir}biomarker/TSS-promotor-background_Asymmetry.gff -o ${Plotdir}"/"${pfx}.fpkm ${Output}${pfx}"/"${pfx}.sort.bam
	python ${Softdir}calculate.py ${Plotdir}"/"${pfx}.fpkm ${Plotdir}"/"${pfx}.fpkm.summary ${Softdir}biomarker/TSS-promotor-background_Asymmetry.gff ${Plotdir}"/"
}


if [ $# -lt 5 ];then
      help_info
      exit -2
else
      option $*
 	fi


if [ ! -f ${Input} ];then
	echo "No such file or dir"
	exit -2
        fi

file=${Input}
pfx=${Name}

echo "....${pfx} is running......."
if [ ! -d ${Output}${pfx}/ ];then
	mkdir -p ${Output}${pfx}/
	fi
	
if [ ! -d ${Plotdir} ];then
	mkdir -p ${Plotdir}
	fi
	
samtools_code
cd ${Output}${pfx}
Getvalue
if [ ! -f ${Plotdir}"/"${pfx}.txt ];then
	echo "file can not found"
	exit -2
else
	rm ${Output}${pfx}"/"${pfx}.*.bam 
	rm ${Plotdir}"/"${pfx}.fpkm
	fi
		
echo "......${pfx} has finished......"




