library(data.table)
args <- commandArgs(T)
soft <- args[1]
nf_path <- args[2]  
file <- list.files(paste(nf_path,"/result/plot/",sep=""),pattern= "*.txt$")

finily <- data.frame()
for(f in file){
  data <- paste(nf_path,"/result/plot/",f,sep="")
  all <- read.table(data,header=T,sep="\t")
  finily <- rbind(finily,all[,c("id","mean_diff","Sample")])
}

save(finily,file=paste(nf_path,"/result/NF.Rdata",sep=""))
load(paste(soft,"/biomarker/NF_NC_normlized.Rdata",sep=""))
test_nc <- merge(finily,gene,by="id")
test_nc$mean_diff <- (test_nc$mean_diff - test_nc$Mean) / test_nc$SD
test_nc <- test_nc[test_nc$id %in% lasso_nc$id,]
test_nc <- dcast(test_nc,"class+Sample~id",value.var="mean_diff")
test_nc[is.na(test_nc)] <- 0

write.table(test_nc,file=paste(nf_path,"/result/","NF.txt",sep=""),quote=F,row.names=F,col.names=F,sep="\t")
