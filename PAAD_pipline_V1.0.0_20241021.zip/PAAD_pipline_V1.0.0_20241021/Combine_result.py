#coding: utf8
#!/bin/python
import os
import sys
import pandas
import pandas as pd
import argparse
import subprocess
import shutil
import time
import datetime
import paramiko
import string
import multiprocessing
import stat


def check_data(path):
	if path[-1] != '/':
		with open(path, 'r') as lines :
			filelist=[]
			for line in lines:
				line = line.strip().split('\t')
				file=line[0]
				filelist.append(file)
			fileNum=len(filelist)
	else:
		filelist=[]
		for root, dirs, files in os.walk(path):
			filelist += files
		fileNum=len(filelist)
	return fileNum


def NF_combine(nf_dir,FLC):
	nf_file= nf_dir + '/result/plot/'
	nf_files=check_data(nf_file)
	if nf_files/2==all_sample_Num:
		nf_cmd = soft_dir + 'NF_model.sh'
		subprocess.call(["bash",nf_cmd,soft_dir,nf_dir,FLC])
	else:
		print("Not have all files NF result")


def CNV_combine(cnv_dir,FLC):
	cnv_result = cnv_dir+'/cnv.score.txt'
	cnv_infofile = cnv_dir+'/cnv_N102.txt'
	cnv_files = check_data(cnv_result)
	need_add0 = []
	if cnv_files==all_sample_Num:
		cnvoutfile=projict_dir+FLC + '/result/biomarker/Comb/CNV.txt'
		cnvinfo_out = projict_dir+FLC + '/result/biomarker/Comb/CNV_info.xls'
		cnvout = open(cnvoutfile,'w')
		with open(cnv_result, 'r') as lines :
			for line in lines:
				line = line.strip().split('\t')
				if line[1]==0 and line[3]!=0 :
					print("Please Check CNV result")
				elif line[3]=='':
					print("Please Check CNV result")
				else:
					print("CNV result don't need Cheak")
				if line[3]=='0':
					need_add0.append(line[0])
				cnvout.write(format('%s\t%s\t%s\n') % (line[0],line[1],line[3]))
			cnvout.close()
	else:
		print("Not have all files CNV result")
	if os.path.getsize(cnv_infofile)>0:
		cnvInout = open(cnvinfo_out,'w')
		cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % ('Sample','Chrom','Start','End','CopyNum','VariationType'))
		with open(cnv_infofile, 'r') as lines:
			for line in lines:
				line = line.strip().split('\t')
				if line[5] == 'del':
					line[5] = 'deletion'
				else:
					line[5] = 'amplification'
				cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (line[0],line[1],line[2],line[3],line[4],line[5]))
		for n in need_add0:
			cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (n,'-','-','-','-','-'))
		cnvInout.close()
	else:
		cnvInout = open(cnvinfo_out,'w')
		cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % ('Sample','Chrom','Start','End','CopyNum','VariationType'))
		with open(cnvoutfile, 'r') as infos:
			for info in infos:
				info = info.strip().split('\t')
				cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (info[0],'-','-','-','-','-'))
			cnvInout.close()
		print("all Sample don't have CNV")

def Fragment_combine(Fragdir,FLC):
	Frag_file=Fragdir+'/split_data/large/Count/run/'
	Frag_files=check_data(Frag_file)
	if Frag_files==all_sample_Num:
		fr_cmd = soft_dir + 'Fragment_model.sh'
		subprocess.call(["bash",fr_cmd,soft_dir,Fragdir,FLC])
	else:
		print("Not have all files Fragment result")

def motif_combine(motifidir,FLC):
	motif_file=motifidir+'/Freq/'
	motif_files=check_data(motif_file)
	if motif_files==all_sample_Num:
		mo_cmd = soft_dir + 'motif_model.sh'
		subprocess.call(["bash",mo_cmd,soft_dir,motifidir,FLC])
	else:
		print("Not have all files motif result")



def Comb_NC_Model(bio_dir,FLC):
	pre_FLC = FLC[0:6]
	NF_SVM = bio_dir + 'NF/result/NF.SVM.txt'
	Fr_SVM = bio_dir + 'Fragment/Fragment.SVM.txt'
	mo_SVM = bio_dir + 'motif/motif.SVM.txt'
	CNV_result = bio_dir + 'Comb/CNV.txt'
	Comb_dir = bio_dir + 'Comb'
	if os.path.isfile(NF_SVM) and os.path.isfile(Fr_SVM) and os.path.isfile(mo_SVM) and os.path.isfile(CNV_result):
		hcc_nc_cmd = soft_dir + 'Model_Combine.R'
		subprocess.call(["Rscript",hcc_nc_cmd,soft_dir,Comb_dir,CNV_result,NC_model_train,NF_SVM,Fr_SVM,mo_SVM])
	else:
		print("Not have all files predict result")


def main():
	parser = argparse.ArgumentParser(description='Combine QC and report')
	#ingroup = parser.add_mutually_exclusive_group(required=True)
	parser.add_argument('-S', '--softdir', help='software dir path')
	parser.add_argument('-a', '--allfile', help='all file list')
	parser.add_argument('-CNV', '--cnvfile', help='CNVfile path')
	parser.add_argument('-f','--flowcell',help='flowcell id',required=True)
	parser.add_argument('-P', '--proJdir', help='project dir',required=True)
	args = parser.parse_args()
	
	global soft_dir
	soft_dir = args.softdir
	if soft_dir[-1] !="/":
		soft_dir+="/"

	global projict_dir
	projict_dir = args.proJdir
	if projict_dir[-1] !="/":
		projict_dir+="/"

	FLC=args.flowcell
	all_file=args.allfile
	cnv_data=args.cnvfile

	nf_dir = projict_dir+ FLC +'/result/biomarker/NF'
	Frag_dir = projict_dir + FLC + '/result/biomarker/Fragment'
	motif_dir= projict_dir + FLC + '/result/biomarker/motif'
	global Combine_dir
	Combine_dir = projict_dir + FLC + '/result/biomarker/Comb/'
	biomarker_dir = projict_dir + FLC + '/result/biomarker/'
	global NC_model_train
	NC_model_train = soft_dir+'biomarker/Comb_train.txt'
	global all_sample_Num
	all_sample_Num=check_data(all_file)
	N=0
	while N<1:
		motif_file=motif_dir+'/Freq/'
		motif_finish_file=check_data(motif_file)
		if motif_finish_file==all_sample_Num:
			CNV_combine(cnv_data,FLC)
			NF_combine(nf_dir,FLC)
			Fragment_combine(Frag_dir,FLC)
			motif_combine(motif_dir,FLC)
			Comb_NC_Model(biomarker_dir,FLC)
			N+=2
		else:
			print ['Not all data finish']
		time.sleep(60)		
	
if __name__ == '__main__':
	main()
				
