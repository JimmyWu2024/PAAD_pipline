/share/work1/wangrr/local/IT_map/MAPPING /share/public/pipeline/RD_Onc/WGS/V0.8/MAPPING_config.xml $1 $2
