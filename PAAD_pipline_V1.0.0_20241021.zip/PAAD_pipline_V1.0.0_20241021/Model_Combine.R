library(data.table)

args <- commandArgs(T)
soft_dir <- args[1]
run_dir <- args[2]
#setwd(run_dir)
####################Input file####################################
CNV <- fread(args[3],header=F)#CNV file
colnames(CNV) <- c("Sample","CNV_score","CNV_num")
train_gl <- args[4] #Comb_train_gl file
test_gl_out <- paste(run_dir,"/Comb_test.txt",sep="")#Comb_test_gl file
LR_gl <- paste(run_dir,"/","Comb_LR.txt",sep="")#Comb_LR_gl file
##################################################################

####################load Input file###############################
NF_gl <- fread(args[5],header=F) #NF file
colnames(NF_gl) <- c("Sample","Real","class","NF_CT","Cir")
Fragment <- fread(args[6],header=F) #Fragment_file
colnames(Fragment) <- c("Sample","Real","class","Fragment_CT","Cir")
motif <- fread(args[7],header=F)#motif_file
colnames(motif) <- c("Sample","Real","class","motif_CT","Cir")
NF_gl <- NF_gl[,c(1,2,4)]
Fragment <- Fragment[,c(1,4)]
motif <- motif[,c(1,4)]
#################################################################
#######################Combine gl test file######################
all <- merge(NF_gl,Fragment,by="Sample")
all <- merge(all,motif,by="Sample")
all <- unique(all,by="Sample")
all <- all[,c(2,1,3,4,5)]
write.table(all,file=test_gl_out,quote=F,row.names=F,col.names=F,sep="\t")
#################################################################
############################# LR for global result##########
system(paste("/software/python2.7.6/bin/python ",soft_dir,"LR_class.py ",train_gl," ",test_gl_out," ",LR_gl,sep=""))
system(paste("bash ",soft_dir,"remove.sh ",LR_gl,sep=""))

lr_gl <- fread(LR_gl,header=F)
colnames(lr_gl) <- c("Sample","Real","class","Comb_CT","NC")
lr_gl <- lr_gl[,c(1,4)]
##########################################################################
##########################Combind all marker result#######################
finily <- merge(CNV,NF_gl,by="Sample",all.y=T)
finily[is.na(finily)] <- 0
finily <- merge(finily,Fragment,by="Sample")
finily <- merge(finily,motif,by="Sample")
finily <- merge(finily,lr_gl,by="Sample")
finily <- unique(finily,by="Sample")
#########################################################################

finily$Comb_gl <- 0
finily$CNV <- 0
finily$GZ2 <- 0
finily$NF <- 0
finily$Fragment <- 0
finily$motif <- 0
finily[finily$CNV_score>0]$CNV <- 1
finily[finily$Comb_CT>=0.4725]$Comb_gl <- 1
finily[finily$NF_CT>=0.5051]$NF <- 1
finily[finily$Fragment_CT>=0.5245]$Fragment <- 1
finily[finily$motif_CT>=0.4677]$motif <- 1
finily$high_risk_count <- finily$NF + finily$Fragment + finily$motif
finily[finily$high_risk_count>=2]$GZ2 <- 1
finily$score <- finily$CNV +finily$GZ2 + finily$Comb_gl
finily[finily$score==0]$score <- finily[finily$score==0]$Comb_CT
finily$high_risk <- "no"
finily[finily$score>=1]$high_risk <- "yes"
finily$risk_level <- "低风险"
finily[finily$score>=1]$risk_level <- "高风险"
finily$Comb_all_CT <- finily$Comb_CT
finily <- finily[order(finily$score,finily$Comb_all_CT,decreasing=T)]
finily$rank <- 1:nrow(finily)
finily$overtake <- (nrow(finily)-finily$rank +1)/nrow(finily)
finily <- finily[order(finily$Sample)]
write.table(finily,file=paste(run_dir,"/finily_all_NC_info.txt",sep=""),quote=F,row.names=F,col.names=T,sep="\t")


