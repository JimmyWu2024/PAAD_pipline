
library(data.table)
args <- commandArgs(T)
file <- args[1]
short_file <- args[2]
large_file <- args[3]
data <- fread(file)
name <- as.character(strsplit(file,"/|.csv")[[1]][length(strsplit(file,"/|.csv")[[1]])])
data <- data[data$type == "P",]
sp1 <- data[data$len>=90 & data$len<=150,]
sp2 <- data[data$len>150 & data$len<=220,]
sp1 <- data.frame(chrom=sp1$chr,start=sp1$pos,end=sp1$pos+sp1$len)
sp1 <- sp1[order(sp1$chrom,sp1$start,sp1$end),]
sp2 <- data.frame(chrom=sp2$chr,start=sp2$pos,end=sp2$pos+sp2$len)
sp2 <- sp2[order(sp2$chrom,sp2$start,sp2$end),]
fwrite(sp1,file=short_file,quote=F,row.names=F,col.names=F,sep="\t")
fwrite(sp2,file=large_file,quote=F,row.names=F,col.names=F,sep="\t")
	


