library(data.table)
args <- commandArgs(T)

Fragment_path <- args[1]
FLC <- args[2]
FLC <- strsplit(FLC,"_")[[1]][1]
short_path <- paste(Fragment_path,"/split_data/short/Count/run/",sep="")
large_path <- paste(Fragment_path,"/split_data/large/Count/run/",sep="")
file <- list.files(short_path)
large <- data.frame()
for(f in file){
data <- fread(paste(large_path,f,sep=""))
colnames(data) <- c("chrom","start","end","large_Count")
data$Sample <- f
large <- rbind(large,data)
}
save(large,file=paste(Fragment_path,"/large.Rdata",sep=""))


short <- data.frame()
library(data.table)
for(f in file){
data <- fread(paste(short_path,f,sep=""))
colnames(data) <- c("chrom","start","end","short_Count")
data$Sample <- f
short <- rbind(short,data)
}
save(short,file=paste(Fragment_path,"/short.Rdata",sep=""))


short$Type <- as.character(paste(short$chrom,short$start,short$end,sep="_"))
large$Type <- as.character(paste(large$chrom,large$start,large$end,sep="_"))
short$chrom <- NULL
short$start <- NULL
short$end <- NULL
large$chrom <- NULL
large$start <- NULL
large$end <- NULL
all <- merge(short,large,by=c("Sample","Type"))
all$ratio <- all$short_Count/ all$large_Count
all$class <- "Cir"
all <- dcast(all,"class+Sample~Type",value.var="ratio")
all[is.na(all)] <- 0
write.table(all,file=paste(Fragment_path,"/Fragment.txt",sep=""),quote=F,row.names=F,col.names=T,sep="\t")


