soft_path=$1
nf_path=$2
FLC=$3
/bin/Rscript ${soft_path}NF_new_data_analyse.R ${soft_path} ${nf_path} ${FLC}

python ${soft_path}SVM/SVM_model.py ${soft_path}biomarker/NF_Model.pkl ${soft_path}biomarker/NF_marker ${nf_path}/result/NF.lasso ${nf_path}/result/NF.SVM.txt
sed -i 's/\[ //g' ${nf_path}/result/NF.SVM.txt
sed -i 's/\]//g' ${nf_path}/result/NF.SVM.txt
sed -i 's/ /\t/g' ${nf_path}/result/NF.SVM.txt
sed -i 's/\t\t/\t/g' ${nf_path}/result/NF.SVM.txt
sed -i 's/ //g' ${nf_path}/result/NF.SVM.txt
sed -i 's/\t\t/\t/g' ${nf_path}/result/NF.SVM.txt
