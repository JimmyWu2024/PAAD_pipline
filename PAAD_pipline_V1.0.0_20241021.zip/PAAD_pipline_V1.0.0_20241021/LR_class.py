import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import cross_validation
from sklearn import datasets
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model.logistic import LogisticRegression
from sklearn.cross_validation import train_test_split,cross_val_score
from sklearn.metrics import roc_curve,auc
import re
import sys 
import optparse
args = sys.argv
filein=open(args[1],'r').readlines()
filetest=open(args[2],'r')
fileout=open(args[3],'w')
arrya=[]
arryb=[]
for line in filein:
	arrya.append(line.strip().split('\t'))
for line in filetest:
	arryb.append(line.strip().split('\t'))
df = pd.DataFrame(arrya[1:], columns=arrya[0])
test=pd.DataFrame(arryb, columns=arrya[0])
train=df
features = df.columns[2:]
y=train['class']
classifier = LogisticRegression()
classifier.fit(train[features], y)
print '$$$$$$$$$',classifier.coef_
print classifier.intercept_
predictions=classifier.predict_proba(test[features])
b=classifier.predict(test[features])
precisions = cross_val_score(classifier, train[features], y,cv=10)
print np.mean(precisions), precisions
for i in range(0,len(b)):
	fileout.write(re.search('\s+(\S+)\nName',str(test['Sample'][i:i+1])).group(1)+'\t'+re.search('\s+(\S+)\nName',str(test['class'][i:i+1])).group(1)+'\t'+b[i]+'\t'+str(predictions[i])+'\n')
fileout.close()
