#!/bin/python
import collections
import optparse
import os
import sys
import mmap
def load_reference_fa(filename):
	dictRefSeq = {}
	with open(filename, 'r') as refSeqFile :
		chrname = ''
		seq = ''
		for line in refSeqFile:
			if(line[0] == '>'):
				if(chrname != ''):
					dictRefSeq[chrname] = seq
				chrname = line[1:].strip()
				seq = ''
			else:
				seq += line.strip().upper()
		if(chrname != ''):
			dictRefSeq[chrname] = seq
	refSeqFile.close()
	return(dictRefSeq)
print('Motif start')
complement = {'A':'T','G':'C','C':'G','T':'A','N':'N','a':'t','g':'c','c':'g','t':'a'}
args = sys.argv
reference_fa = args[1]
fa_dict = load_reference_fa(reference_fa)
input_file = args[2]#Input file
output_dir = args[3]#outfile dir
if output_dir[-1] != '/':
    output_dir += '/'

filename=args[4]#outfile name
Chr_list = ['chr1','chr2','chr3','chr4','chr5','chr6','chr7','chr8','chr9','chr10','chr11','chr12','chr13','chr14','chr15','chr16','chr17','chr18','chr19','chr20','chr21','chr22','chrX']


motif=[]
infile = input_file
with open(infile, 'r') as posinfo :
	lines = posinfo
	next(lines,None)
	array = []
	for line in lines:
		line = line.strip().split('\t')
		if line[0] != 'S':
			if line[1] in Chr_list:
				sLpos = int(line[2]) - 1
				sRpos = sLpos + 4
				eRpos = int(line[2]) + int(line[3]) - 1
				eLpos = eRpos - 4
				if sLpos>0 and eLpos>0:
					sSeq = fa_dict[line[1]][sLpos:sRpos]
					eSeq = fa_dict[line[1]][eLpos:eRpos]
					eSeq = complement[eSeq[3]] + complement[eSeq[2]] +complement[eSeq[1]] +complement[eSeq[0]]
					motif.append(sSeq)
					motif.append(eSeq)
Count=collections.Counter(motif)
Count=dict(Count)
outfile = output_dir + filename
fileout = open(outfile,'w')
for dict_key in Count.keys():
	fileout.write(format('%s\t%s\n') % (dict_key,Count[dict_key]))
fileout.close()
print('Motif_END')
