soft=$1 # software path
rawbam=$2 #raw bam file
pfx=$3 # clean bamfile name pfx
bio_dr=$4 # run dir path(not incloude "/" at the path end)
#pfx=${name##*/}
rmdup="${bio_dr}Fragment/rmdup/"
sortbam="${bio_dr}Fragment/sortbam/"
output="${bio_dr}Fragment/result/sup/"
short_input="${bio_dr}Fragment/split_data/short/raw/run/"
short_output="${bio_dr}Fragment/split_data/short/Count/run/"
large_input="${bio_dr}Fragment/split_data/large/raw/run/"
large_output="${bio_dr}Fragment/split_data/large/Count/run/"
echo "Fragment Strat"
if [ ! -d ${rmdup} ];then
        mkdir -p ${rmdup}
        fi
if [ ! -d ${sortbam} ];then
        mkdir -p ${sortbam}
        fi
if [ ! -d ${output} ];then
        mkdir -p ${output}
        fi
if [ ! -d ${short_input} ];then
        mkdir -p ${short_input}
        fi
if [ ! -d ${short_output} ];then
        mkdir -p ${short_output}
        fi
if [ ! -d ${large_input} ];then
        mkdir -p ${large_input}
        fi
if [ ! -d ${large_output} ];then
        mkdir -p ${large_output}
        fi

samtools view -bSh -F 1804 -q 20 ${rawbam} > ${rmdup}${pfx}.rmdup.bam
samtools sort -n -@ 5 -m 2G ${rmdup}${pfx}.rmdup.bam > ${sortbam}${pfx}.sort.bam
rm ${rmdup}${pfx}.rmdup.bam  
python ${soft}flagment_len.py ${sortbam}${pfx}.sort.bam -o ${output}${pfx}.csv
rm ${sortbam}${pfx}.sort.bam
Rscript ${soft}split_short_large_single_test.R ${output}${pfx}.csv ${short_input}${pfx} ${large_input}${pfx}
bedtools intersect -a ${soft}biomarker/Genom_region_span1M  -b ${short_input}${pfx} -c  > ${short_output}${pfx}
bedtools intersect -a ${soft}biomarker/Genom_region_span1M  -b ${large_input}${pfx} -c  > ${large_output}${pfx}
rm ${short_input}${pfx} ${large_input}${pfx}
echo "Fragment END"
