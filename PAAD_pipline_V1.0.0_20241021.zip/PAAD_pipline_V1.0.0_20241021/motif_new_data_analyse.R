library(data.table)
args <- commandArgs(T)
motif_path <- args[1]
FLC <- args[2]
file <- list.files(paste(args[1],"/Freq/",sep=""))
motif_new <- data.table()
for(f in file){
sp <- fread(paste(args[1],"/Freq/",f,sep=""),header=F)
colnames(sp) <- c("Type","Count")
sp$Sample <- as.character(strsplit(f,".csv")[[1]][1])
message(as.character(strsplit(f,".csv")[[1]][1]))
sp <- sp[-grep("N",sp$Type)]
sp$class <- "NC"
motif_new <- rbind(motif_new,sp)
}
motif_new[,total:=sum(Count),by=Sample]
motif_new$Freq <- (motif_new$Count / motif_new$total) * 100
motif_new <- dcast(motif_new,"class+Sample~Type",value.var="Freq")
save(motif_new,file=paste(args[1],"/motif.Rdata",sep=""))

write.table(motif_new,file=paste(args[1],"/motif.txt",sep=""),quote=F,row.names=F,col.names=T,sep="\t")
