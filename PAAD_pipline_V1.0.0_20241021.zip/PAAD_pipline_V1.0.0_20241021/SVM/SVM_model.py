import random
import re
import os
import pprint
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.gaussian_process import GaussianProcessClassifier
from sklearn.model_selection import GridSearchCV,RandomizedSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.gaussian_process.kernels import RBF, Matern
from sklearn.linear_model import SGDClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, RobustScaler, MinMaxScaler
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc, roc_auc_score
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.linear_model import LassoCV, Lasso
from sklearn.feature_selection import SelectFromModel
from sklearn.multiclass import OneVsRestClassifier, OneVsOneClassifier
from sklearn.externals import joblib
from sklearn.decomposition import PCA
from sklearn.model_selection import StratifiedShuffleSplit
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.gridspec as gridspec
import seaborn as sns
import sys

random.seed(100)
args = sys.argv
pkl=args[1]
filetest=open(args[3],'r')
fileout=open(args[4],'w')

arryb=[]
for line in filetest:
	arrytemp=line.strip().split('\t')
	arryb.append(arrytemp)
test=pd.DataFrame(arryb, columns=arrya[0])
clf=joblib.load(pkl)
features = joblib.load(args[2])
#clf =SVC(C=19, cache_size=200, class_weight=None, coef0=0.0, decision_function_shape='None', degree=3, gamma=0.5, kernel='rbf', max_iter=-1, random_state=1, shrinking=True, tol=0.001, verbose=False,probability=True)
b=clf.predict(test[features])
a= clf.predict_proba(test[features])
for i in range(0,len(b)):
	fileout.write(re.search('\s+(\S+)\nName',str(test['Sample'][i:i+1])).group(1)+'\t'+re.search('\s+(\S+)\nName',str(test['class'][i:i+1])).group(1)+'\t'+b[i]+'\t'+str(a[i])+'\n')
fileout.close()
