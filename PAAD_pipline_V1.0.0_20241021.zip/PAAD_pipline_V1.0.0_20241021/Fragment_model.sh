soft_path=$1
Frag_path=$2
Rscript ${soft_path}Fragment_new_data_analyse.R ${Frag_path} ${FLC}
python ${soft_path}SVM/SVM_model.py ${soft_path}biomarker/Fragment_Model.pkl ${soft_path}biomarker/Fragment_marker ${Frag_path}/Fragment.txt ${Frag_path}/Fragment.SVM.txt
sed -i 's/\[ //g' ${Frag_path}/Fragment.SVM.txt
sed -i 's/\]//g' ${Frag_path}/Fragment.SVM.txt
sed -i 's/ /\t/g' ${Frag_path}/Fragment.SVM.txt
sed -i 's/\t\t/\t/g' ${Frag_path}/Fragment.SVM.txt
sed -i 's/\t\t/\t/g' ${Frag_path}/Fragment.SVM.txt

