soft_path=$1
motif_path=$2
FLC=$3
Rscript ${soft_path}motif_new_data_analyse.R ${motif_path} ${FLC}

python ${soft_path}SVM/SVM_model.py ${soft_path}biomarker/motif_Model.pkl ${soft_path}biomarker/motif_marker ${motif_path}/motif.txt ${motif_path}/motif.SVM.txt
sed -i 's/\[//g' ${motif_path}/motif.SVM.txt
sed -i 's/\]//g' ${motif_path}/motif.SVM.txt
sed -i 's/  /\t/g' ${motif_path}/motif.SVM.txt
sed -i 's/ /\t/g' ${motif_path}/motif.SVM.txt
sed -i 's/\t\t/\t/g' ${motif_path}/motif.SVM.txt

