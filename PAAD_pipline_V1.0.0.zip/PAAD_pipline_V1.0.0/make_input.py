# -*- coding: utf-8 -*-
"""
Created on Wed Aug 25 10:30:14 2021

@author: ***
"""
import os
import re
import pandas as pd
import argparse



def Input_file(all_fastq_dir_dic,From_XQ_bam,Input_file_name,ln_file_name):
    dic_fastq={}
    for i in From_XQ_bam:
        for j in all_fastq_dir_dic.keys():
            if i in j:
                R_number = j.split(".")[1]
                LibName = j.split("_")[1]
                if i in dic_fastq:
                    dic_fastq[i][R_number]=j
                else:
                    dic_fastq[i]={}
                    dic_fastq[i][R_number]=j
                    dic_fastq[i]["L"]=LibName
            
    with open (Input_file_name,"w") as outp:
        for key,value in dic_fastq.items():
            outp.writelines(str(key) + "\t" + all_fastq_dir_dic[str(dic_fastq[key]["R1"])] + str(dic_fastq[key]["R1"]) + "\t" + all_fastq_dir_dic[str(dic_fastq[key]["R1"])] + str(dic_fastq[key]["R2"]) +"\t" + "H1" + "\t" +  str(dic_fastq[key]["L"]) + "\n")
    
    with open (ln_file_name,"w") as output:
        for key,value in dic_fastq.items():
            output.writelines("ln -s" + " " + all_fastq_dir_dic[str(dic_fastq[key]["R1"])] + str(dic_fastq[key]["R1"]) + " " + Input_dir+"result/biomarker/CNV/data/" + "\n")
  
    
    
def fastq_file_to_dir(fastq_dir_name):
    if os.path.exists(fastq_dir_name):
        fastq_dir_file = os.listdir(fastq_dir_name)
        fastq_list = [ i for i in fastq_dir_file if "fastq" in i ]
        fastq_file_dic = {i:fastq_dir_name for i in fastq_list}
    else:
        fastq_file_dic = {}
    
    return fastq_file_dic


    
def main():
    
    
    parser = argparse.ArgumentParser(description='Analytical Process')
    	#ingroup = parser.add_mutually_exclusive_group(required=True)
    parser.add_argument('-Clin', '--XQpath', help='Xuqiu path',required=True)  #e.g./share/Oncology/Onc_LDWGS/Xuqiu/210820_Novaseq_A00399B_BHH2GGDSX2_PRE-HCC(LD-WGS)_LD-WGS_v01_FZ.xls
    parser.add_argument('-f', '--fastqdir', help='fastq directory',required=True) #e.g. /share/seq_dir/ngs/SS/BBFC20200015/
    parser.add_argument('-name', '--FLC', help='FLC name',required=True)
    parser.add_argument('-i','--Inputdir',help='Analysis directory',required=True) #e.g. /share/Oncology/Onc_LDWGS/210820_A00399_0318_BHH2GGDSX2
    args = parser.parse_args()
    
    #-------------fastq_dir--------------#
    global all_fastq_dir_dic
    fastq_dir = args.fastqdir
    if fastq_dir[-1] != '/':
    		fastq_dir += '/'                
    
    flowcell_name = args.FLC
    fastq_dir_first = "/share/Onc_SeqDir_V2/T7/" + flowcell_name + "/"
    
    fastq_dir1_dic = fastq_file_to_dir(fastq_dir_first)
    all_fastq_dir_dic = dict(fastq_dir1_dic.items())
        
    
    #-------------xuqiu_file--------------#

    XQ_path = args.XQpath
    xuqiu_list=os.listdir(XQ_path)
    pre_flc = flowcell_name.split('_')[3]
    for F in xuqiu_list:
        if pre_flc in F:
            XQ_file = XQ_path + F
    analysis_file = pd.read_csv(XQ_file,sep='\t',header=0,index_col=0) 
    From_XQ_bam = analysis_file["SampleID"].tolist()    
    not_found_XQfile = [i for i in From_XQ_bam if i not in ''.join(all_fastq_dir_dic.keys())]

    #-------------Input_dir--------------#
    global Input_dir
    Input_dir = args.Inputdir
    if Input_dir[-1] != '/':
    		Input_dir += '/'
            
    #-------------judge & run--------------#        
    if os.path.exists(fastq_dir_first+"report"):
        if len(not_found_XQfile) == 0:
            Input_file_name = Input_dir+"Input.txt"
            ln_file_name = Input_dir+"ln.sh"
            Input_file(all_fastq_dir_dic,From_XQ_bam,Input_file_name,ln_file_name)          
        else:
            print ['Not all data found']
    else:
        print ['Data splitting not completed']




if __name__ == '__main__':
	main()
				

