from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import r2_score
from sklearn import svm
from sklearn.svm import SVC
from sklearn import preprocessing
import pandas as pd
import numpy as np
import re
import random
import sys
import optparse
from sklearn.preprocessing import StandardScaler

random.seed(100)
args = sys.argv
filein=open(args[1],'r').readlines()
filetest=open(args[2],'r')
fileout=open(args[3],'w')

arrya=[]
arryb=[]
for line in filein:
	arrytemp=line.strip().split('\t')
	arrya.append(arrytemp)
for line in filetest:
	arrytemp=line.strip().split('\t')
	arryb.append(arrytemp)
df = pd.DataFrame(arrya[1:], columns=arrya[0])
test=pd.DataFrame(arryb, columns=arrya[0])
train=df
features = df.columns[2:]
clf =SVC(C=19, cache_size=200, class_weight=None, coef0=0.0, decision_function_shape='None', degree=3, gamma=0.5, kernel='rbf', max_iter=-1, random_state=1, shrinking=True, tol=0.001, verbose=False,probability=True)
y=train['class']
clf.fit(train[features], y)
b=clf.predict(test[features])
a= clf.predict_proba(test[features])
print clf.score(train[features], y)
print b
print a
for i in range(0,len(b)):
	fileout.write(re.search('\s+(\S+)\nName',str(test['Sample'][i:i+1])).group(1)+'\t'+re.search('\s+(\S+)\nName',str(test['class'][i:i+1])).group(1)+'\t'+b[i]+'\t'+str(a[i])+'\n')
fileout.close()
