import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import cross_validation
from sklearn import datasets
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model.logistic import LogisticRegression
from sklearn.cross_validation import train_test_split,cross_val_score
from sklearn.metrics import roc_curve,auc
import re
import sys 
import optparse
args = sys.argv
filein=open(args[1],'r').readlines()
filetest=open(args[2],'r')
fileout=open(args[3],'w')
arrya=[]
arryb=[]
for line in filein:
	arrya.append(line.strip().split('\t'))
for line in filetest:
	arryb.append(line.strip().split('\t'))
#df=pd.read_csv('SMSSpamCollection',delimiter='\t',header=None)
#df['label']=pd.factorize(df['label'])[0]
#X_train_raw, X_test_raw, y_train, y_test = train_test_split(df['message'],df['label'])
#vectorizer = TfidfVectorizer()
#X_train = vectorizer.fit_transform(X_train_raw)
#X_test = vectorizer.transform(X_test_raw)
#X_train=[[1,1,1],[1,1,1],[0,0,0]]
#y_train=[[1],[1],[0]]
#X_test=[[1,1,1],[0,0,0]]
#iris = datasets.load_iris()
#X_train, X_test, y_train, y_test = cross_validation.train_test_split(iris.data[:80], iris.target[:80], test_size=0.4, random_state=0)
#print X_train.shape, y_train.shape
df = pd.DataFrame(arrya[1:], columns=arrya[0])
test=pd.DataFrame(arryb, columns=arrya[0])
train=df
features = df.columns[2:]
y=train['class']
classifier = LogisticRegression()
classifier.fit(train[features], y)
print '$$$$$$$$$',classifier.coef_
print classifier.intercept_
predictions=classifier.predict_proba(test[features])
print predictions
b=classifier.predict(test[features])
print b
precisions = cross_val_score(classifier, train[features], y,cv=10)
print np.mean(precisions), precisions
for i in range(0,len(b)):
	fileout.write(re.search('\s+(\S+)\nName',str(test['Sample'][i:i+1])).group(1)+'\t'+re.search('\s+(\S+)\nName',str(test['class'][i:i+1])).group(1)+'\t'+b[i]+'\t'+str(predictions[i])+'\n')
fileout.close()
	
'''
false_positive_rate, recall, thresholds = roc_curve(y_test, predictions[:,1])
roc_auc=auc(false_positive_rate,recall)
plt.title('Receiver Operating Characteristic')
plt.plot(false_positive_rate, recall, 'b', label='AUC = %0.2f' % roc_auc)
plt.legend(loc='lower right')
plt.plot([0,1],[0,1],'r--')
plt.xlim([0.0,1.0])
plt.ylim([0.0,1.0])
plt.ylabel('Recall')
plt.xlabel('Fall-out')
plt.show()
'''
