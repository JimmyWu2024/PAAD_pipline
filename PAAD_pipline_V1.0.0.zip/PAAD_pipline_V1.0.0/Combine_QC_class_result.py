#coding: utf8
#!/share/work3/yangh3857/software/miniconda2/bin/python
import os
import sys
import pandas
import pandas as pd
import argparse
import subprocess
import shutil
import time
import datetime
import paramiko
import string
import multiprocessing
import stat


def check_data(path):
	if path[-1] != '/':
		with open(path, 'r') as lines :
			filelist=[]
			for line in lines:
				line = line.strip().split('\t')
				file=line[0]
				filelist.append(file)
			fileNum=len(filelist)
	else:
		filelist=[]
		for root, dirs, files in os.walk(path):
			filelist += files
		fileNum=len(filelist)
	return fileNum


def NF_combine(nf_dir,FLC):
	nf_file= nf_dir + '/result/plot/'
	nf_files=check_data(nf_file)
	if nf_files/2==all_sample_Num:
		nf_cmd = soft_dir + 'NF_model.sh'
		subprocess.call(["bash",nf_cmd,soft_dir,nf_dir,FLC])
	else:
		print("Not have all files NF result")


def CNV_combine(cnv_dir,FLC):
	cnv_result = cnv_dir+'/cnv.score.txt'
	cnv_infofile = cnv_dir+'/cnv_N102.txt'
	cnv_files = check_data(cnv_result)
	need_add0 = []
	if cnv_files==all_sample_Num:
		cnvoutfile=projict_dir+FLC + '/result/biomarker/Comb/CNV.txt'
		cnvinfo_out = projict_dir+FLC + '/result/biomarker/Comb/CNV_info.xls'
		cnvout = open(cnvoutfile,'w')
		with open(cnv_result, 'r') as lines :
			for line in lines:
				line = line.strip().split('\t')
				if line[1]==0 and line[3]!=0 :
					print("Please Check CNV result")
				elif line[3]=='':
					print("Please Check CNV result")
				else:
					print("CNV result don't need Cheak")
				if line[3]=='0':
					need_add0.append(line[0])
				cnvout.write(format('%s\t%s\t%s\n') % (line[0],line[1],line[3]))
			cnvout.close()
	else:
		print("Not have all files CNV result")
	if os.path.getsize(cnv_infofile)>0:
		cnvInout = open(cnvinfo_out,'w')
		cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % ('Sample','Chrom','Start','End','CopyNum','VariationType'))
		with open(cnv_infofile, 'r') as lines:
			for line in lines:
				line = line.strip().split('\t')
				if line[5] == 'del':
					line[5] = 'deletion'
				else:
					line[5] = 'amplification'
				cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (line[0],line[1],line[2],line[3],line[4],line[5]))
		for n in need_add0:
			cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (n,'-','-','-','-','-'))
		cnvInout.close()
	else:
		cnvInout = open(cnvinfo_out,'w')
		cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % ('Sample','Chrom','Start','End','CopyNum','VariationType'))
		with open(cnvoutfile, 'r') as infos:
			for info in infos:
				info = info.strip().split('\t')
				cnvInout.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (info[0],'-','-','-','-','-'))
			cnvInout.close()
		print("all Sample don't have CNV")

def Fragment_combine(Fragdir,FLC):
	Frag_file=Fragdir+'/split_data/large/Count/run/'
	Frag_files=check_data(Frag_file)
	if Frag_files==all_sample_Num:
		fr_cmd = soft_dir + 'Fragment_model.sh'
		subprocess.call(["bash",fr_cmd,soft_dir,Fragdir,FLC])
	else:
		print("Not have all files Fragment result")

def motif_combine(motifidir,FLC):
	motif_file=motifidir+'/Freq/'
	motif_files=check_data(motif_file)
	if motif_files==all_sample_Num:
		mo_cmd = soft_dir + 'motif_model.sh'
		subprocess.call(["bash",mo_cmd,soft_dir,motifidir,FLC])
	else:
		print("Not have all files motif result")

def QC_combine(QCdir,FLC):
	QC_list=[]
	for root, dirs, files in os.walk(QCdir):
		QC_list += dirs
	QC_files = len(QC_list)
	if QC_files==all_sample_Num:
		QC_cmd = soft_dir + 'QC_report.R'
		subprocess.call(["Rscript",QC_cmd,projict_dir,FLC,soft_dir])
	else:
		print("Not have all files QC result")


def check_qc_file(QCdir,FLC):
        file_count = os.popen("ls %s/*/*.QC.xls|wc -l"%QCdir).read().strip()
        if int(file_count)==all_sample_Num:
                print("All sample have files QC result")
                return True
        else:
                print("Not have all files QC result")
                return False


def Comb_NC_Model(bio_dir,FLC):
	pre_FLC = FLC[0:6]
	NF_SVM = bio_dir + 'NF/result/NF_' + pre_FLC + '_NC.SVM.txt'
	Fr_SVM = bio_dir + 'Fragment/Fragment_' + pre_FLC + '_NC.SVM.txt'
	mo_SVM = bio_dir + 'motif/motif_' + pre_FLC + '_NC.SVM.txt'
	CNV_result = bio_dir + 'Comb/CNV.txt'
	Comb_dir = bio_dir + 'Comb'
	if os.path.isfile(NF_SVM) and os.path.isfile(Fr_SVM) and os.path.isfile(mo_SVM) and os.path.isfile(CNV_result):
		hcc_nc_cmd = soft_dir + 'HCC_NC_Model_Combine.R'
		subprocess.call(["Rscript",hcc_nc_cmd,soft_dir,Comb_dir,CNV_result,NC_model_train,NF_SVM,Fr_SVM,mo_SVM])
	else:
		print("Not have all files predict result")

def Comb_Cir_Model(bio_dir,FLC):
	pre_FLC = FLC[0:6]
	NF_SVM = bio_dir + 'NF/result/NF_' + pre_FLC + '_Cir.SVM.txt'
	Fr_SVM = bio_dir + 'Fragment/Fragment_' + pre_FLC + '_Cir.SVM.txt'
	mo_SVM = bio_dir + 'motif/motif_' + pre_FLC + '_Cir.SVM.txt'
	CNV_result = bio_dir + 'Comb/CNV.txt'
	Comb_dir = bio_dir + 'Comb'
	if os.path.isfile(NF_SVM) and os.path.isfile(Fr_SVM) and os.path.isfile(mo_SVM) and os.path.isfile(CNV_result):
		hcc_cir_cmd = soft_dir + 'HCC_Cir_Model_Combine.R'
		subprocess.call(["Rscript",hcc_cir_cmd,soft_dir,Comb_dir,CNV_result,Cir_model_train,NF_SVM,Fr_SVM,mo_SVM])
	else:
		print("Not have all files predict result")


def Comb_JJ_Model(bio_dir,FLC):
	pre_FLC = FLC[0:6]
	NF_SVM = bio_dir + 'NF/result/NF_' + pre_FLC + '_JJ.SVM.txt'
	Fr_SVM = bio_dir + 'Fragment/Fragment_' + pre_FLC + '_JJ.SVM.txt'
	mo_SVM = bio_dir + 'motif/motif_' + pre_FLC + '_JJ.SVM.txt'
	CNV_result = bio_dir + 'Comb/CNV.txt'
	Comb_dir = bio_dir + 'Comb'
	if os.path.isfile(NF_SVM) and os.path.isfile(Fr_SVM) and os.path.isfile(mo_SVM) and os.path.isfile(CNV_result):
		hcc_JJ_cmd = soft_dir + 'HCC_JJ_Model_Combine.R'
		subprocess.call(["Rscript",hcc_JJ_cmd,soft_dir,Comb_dir,CNV_result,Cir_model_train,NF_SVM,Fr_SVM,mo_SVM])
	else:
		print("Not have all files predict result")


def get_clininfo(Clin_dir,FLC):
	data_list=os.listdir(Clin_dir)
	pre_flc = FLC.split('_')[3]
	for F in data_list:
		if pre_flc in F:
			target_file = Clin_dir + F
			subprocess.call(["python","/share/Onc_RD_ZS/RD/LDWGS_V2/LD_WGS_V3.0.0/get_clin_info.py",target_file,Combine_dir])

def get_report_file(Comb_dir):
	Cir_report = Comb_dir + 'report_Cir.xls'
	NC_report = Comb_dir + 'report_NC.xls'
	JJ_report = Comb_dir + 'report_JJ.xls'
	Cir_target = Comb_dir + 'Cir.list'
	NC_target = Comb_dir + 'Other.list'
	JJ_target = Comb_dir + 'Clininfo.list'
	report_file = Comb_dir + 'report.xls'
	Cir_list=[]
	NC_list=[]
	JJ_list=[]
	with open(JJ_target, 'r') as JJs :
		for jj in JJs:
			jj = jj.strip().split('\t')
			if jj[2] == 'HAVE':
				JJ_list.append(jj[0])

	with open(Cir_target, 'r') as CIRs :
		for cir in CIRs:
			cir = cir.strip().split('\t')
			Cir_list += cir
	
	if os.path.isfile(Cir_report) and os.path.isfile(NC_report) and os.path.isfile(JJ_report):
		report=open(report_file,'w')
		report.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % ('sample','high_risk','score','risk_level','rank','overtake'))
		with open(Cir_report,'r') as CirInfos:
			for cirinfo in CirInfos:
				cirinfo = cirinfo.strip().split('\t')
				sampleid = cirinfo[0]
				if sampleid in Cir_list and sampleid not in JJ_list:
					report.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (cirinfo[0],cirinfo[1],cirinfo[2],cirinfo[3],cirinfo[4],cirinfo[5]))
				elif sampleid in JJ_list:
					with open(JJ_report,'r') as JJInfos:
						for jjinfo in JJInfos:
							jjinfo = jjinfo.strip().split('\t')
							if jjinfo[0] == sampleid and jjinfo[0]!='sample':
								report.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (jjinfo[0],jjinfo[1],jjinfo[2],jjinfo[3],jjinfo[4],jjinfo[5]))
				else:
					with open(NC_report,'r') as NCInfos:
						for ncinfo in NCInfos:
							ncinfo = ncinfo.strip().split('\t')
							if ncinfo[0] == sampleid and ncinfo[0]!='sample':
								report.write(format('%s\t%s\t%s\t%s\t%s\t%s\n') % (ncinfo[0],ncinfo[1],ncinfo[2],ncinfo[3],ncinfo[4],ncinfo[5]))
		report.close()
	else:
		print("Not have all Model report")

def get_biomarker_info(Comb_dir):
	bio_report = Comb_dir + 'biomarker_report.xls'
	bio_Cir = Comb_dir + 'biomarker_Cir.xls'
	bio_NC = Comb_dir + 'biomarker_NC.xls'
	bio_JJ = Comb_dir + 'biomarker_JJ.xls'
	Cir_list = []
	NC_list = []
	JJ_list = []
	JJ_target = Comb_dir + 'Clininfo.list'
	Cir_target = Comb_dir + 'Cir.list'
	with open(JJ_target, 'r') as JJs :
		for jj in JJs:
			jj = jj.strip().split('\t')
			if jj[2] == 'HAVE':
				JJ_list.append(jj[0])

	with open(Cir_target, 'r') as CIRs :
		for cir in CIRs:
			cir = cir.strip().split('\t')
			Cir_list += cir
	if os.path.isfile(bio_Cir) and os.path.isfile(bio_NC) and os.path.isfile(bio_JJ):
		bio_out = open(bio_report,'w')
		bio_out.write(format('%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n') % ('Sample','NF_CT','NF_Rank','Fragment_CT','Fragment_Rank','motif_CT','motif_Rank','CNV_score'))
		with open(bio_Cir,'r') as bio_CIRs:
			for bio_cir in bio_CIRs:
				bio_cir = bio_cir.strip().split('\t')
				sampleid = bio_cir[0]
				if sampleid in Cir_list and sampleid not in JJ_list:
					bio_out.write(format('%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n') % (bio_cir[0],bio_cir[2],bio_cir[3],bio_cir[4],bio_cir[5],bio_cir[6],bio_cir[7],bio_cir[1]))
				elif sampleid in JJ_list:
					with open(bio_JJ,'r') as bio_JJs:
						for bio_jj in bio_JJs:
							bio_jj = bio_jj.strip().split('\t')
							if bio_jj[0] == sampleid and bio_jj[0]!='Sample':
								 bio_out.write(format('%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n') % (bio_jj[0],bio_jj[2],bio_jj[3],bio_jj[4],bio_jj[5],bio_jj[6],bio_jj[7],bio_jj[1]))									
				else:
					with open(bio_NC,'r') as bio_NCs:
						for bio_nc in bio_NCs:
							bio_nc = bio_nc.strip().split('\t')
							if bio_nc[0] == sampleid and bio_nc[0]!='Sample':
								bio_out.write(format('%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n') % (bio_nc[0],bio_nc[2],bio_nc[3],bio_nc[4],bio_nc[5],bio_nc[6],bio_nc[7],bio_nc[1]))
		bio_out.close()	
	else:
		print("Not have all Model biomarker report")

def get_use_time(PJ_dir,FLC):
	time_now=datetime.datetime.now().strftime('%Y/%m/%d')
	input_dir=projict_dir + FLC
	if input_dir[-1] != '/':
    		input_dir += '/'
	outfile = Combine_dir + 'time.xls'
	start_path = input_dir+'result/data/'
	end_path = input_dir+'result/biomarker/'
	all_time=[]
	file_list = os.listdir(start_path)
	for f in file_list:
		start_temp=start_path+f+'/H1/L1/fastp_'+f+'_H1_L1.mark'
		S=open(start_temp,'r').readlines()
		S_time=str(S[0].split(' ')[3])
		S_time=time_now+','+S_time
		end_temp=end_path+f+'/biomarker_'+f+'.mark'
		E=open(end_temp,'r').readlines()
		E_time=str(E[0].split(' ')[3])
		E_time=time_now+','+E_time
		array=[f,S_time,E_time]
		S_time = datetime.datetime.strptime(S_time,'%Y/%m/%d,%H:%M:%S')
		E_time = datetime.datetime.strptime(E_time,'%Y/%m/%d,%H:%M:%S')
		used=round(float((E_time-S_time).seconds) / 3600,2)
		report_time=datetime.datetime.now().strftime('%Y/%m/%d,%H:%M:%S')
		array.append(used)
		array.append(report_time)
		all_time.append(array)

	fileout = open(outfile,'w')
	fileout.write(format('%s\t%s\t%s\t%s\t%s\n') % ('Sample','start_time','end_time','time_used(hour)','report_complete_time'))
	for n in range(0,len(all_time)):
        	line = all_time[n]
        	fileout.write(format('%s\t%s\t%s\t%s\t%s\n') % (line[0], line[1], line[2], line[3],line[4]))
	fileout.close()	
	print("all Sample run finish")

def biomarker_plot(Comb_dir,plot_dir):
	bioplot_info = Comb_dir + 'biomarker_report.xls'
	if os.path.isfile(bioplot_info):
		with open(bioplot_info,'r') as plot_info:
			for plot in plot_info:
				plot = plot.strip().split('\t')
				if plot[0] != 'Sample':
					subprocess.call(["Rscript","/share/Onc_RD_ZS/RD/LDWGS_V2/LD_WGS_V3.0.0/biomarker_plot.R",plot_dir,plot[0],'NF',plot[1]])
					subprocess.call(["Rscript","/share/Onc_RD_ZS/RD/LDWGS_V2/LD_WGS_V3.0.0/biomarker_plot.R",plot_dir,plot[0],'Motif',plot[5]])
					subprocess.call(["Rscript","/share/Onc_RD_ZS/RD/LDWGS_V2/LD_WGS_V3.0.0/biomarker_plot.R",plot_dir,plot[0],'Other',plot[3]])
	else:
		print("Not have biomarker plot file")

def get_email_data(Comb_dir,FLC):
	subprocess.call(["Rscript","/share/Onc_RD_ZS/RD/LDWGS_V2/LD_WGS_V3.0.0/CNV_check.R",Comb_dir])
        QC_file = projict_dir + FLC + '/result/bam/' + FLC + '_PRE-HCC_QC.xls'
        report_file = Comb_dir + 'report.xls'
        time_file = Comb_dir + 'time.xls'
        biomarker_file = Comb_dir + 'biomarker_report.xls'
        CNV_info_file = Comb_dir + 'CNV_info.xls'
	CNV_result = Comb_dir + 'CNV_Check.xls'
        Double_M_file = Comb_dir + 'Double_model.xls'
	check_file_path= Comb_dir + 'Check_file.xls'
	QC = pd.read_table(QC_file,sep='\t',header=0)
	QC = QC.loc[:,['sample','QC_result']]
	cnv_check = pd.read_table(CNV_result,sep='\t',header=0)
	cnv_check.rename(columns={'Sample':'sample'},inplace=True)
	report = pd.read_table(report_file,sep='\t',header=0)
	report = report.loc[:,["sample","high_risk","score","risk_level"]]
	DM = pd.read_table(Double_M_file,sep='\t',header=0)
	DM.rename(columns={'Sample':'sample'},inplace=True)
	check_file = pd.merge(QC,report,on='sample')
	check_file = pd.merge(check_file,cnv_check,on='sample')
	#check_file = pd.merge(check_file,DM,on='sample')
	check_file.index=range(1,len(check_file.index)+1)
	check_file.to_csv(check_file_path,sep='\t',float_format='%.2f')
	finily_file = Comb_dir + FLC + '_PRE-HCC_LD-WGS_v03.report.xls'
	finily_cmd=soft_dir + 'message_Auto_run_result.py'
	subprocess.call([finily_cmd,QC_file,report_file,time_file,biomarker_file,CNV_info_file,Double_M_file,finily_file])
	rsync_report = "rsync -e 'ssh -p 3033' " +finily_file + ' oncology@10.100.14.8:/zonghe/sharedisk/gps-shared/PRE/'+ FLC + '_PRE-HCC_LD-WGS_v03.report/'
	os.system(rsync_report)
	ssh = paramiko.SSHClient()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(hostname='10.100.14.8', port=3033, username='oncology', password='onc@2020')
	tran = ssh.get_transport()
	sftp = paramiko.SFTPClient.from_transport(tran)
	targetpath = '/zonghe/sharedisk/gps-shared/PRE/'+FLC+'_PRE-HCC_LD-WGS_v03.report/'
	targetfile = sftp.listdir_attr(targetpath)[0].filename
	if FLC in targetfile:
		print 'report file Upload Succeeded'
	else:
		print 'report file Upload Failed'

def zip_scp_plot(plot_dir,FLC):
	plot_num=check_data(plot_dir)
	if plot_num/3 == all_sample_Num:
		zipfile_code  = 'zip -j ' +  Combine_dir + 'biomarker_plot.zip ' + plot_dir + '*.png'
		rsync_cmd = "rsync -e 'ssh -p 3033' " + plot_dir + '*.png ' + 'oncology@10.100.14.8:/zonghe/sharedisk/gps-shared/LDWGS_Image/' + FLC + '_PRE-HCC_LD-WGS'
		os .system(zipfile_code)
		os .system(rsync_cmd)
	else:
		print("Not have all plot file")

def get_Double_Model(Comb_dir):
	Cir_report = Comb_dir + 'report_Cir.xls'
	NC_report = Comb_dir + 'report_NC.xls'
	JJ_report = Comb_dir + 'report_JJ.xls'
	Double_Model = Comb_dir + 'Double_model.xls'
	Cir_target = Comb_dir + 'Cir.list'
	JJ_target = Comb_dir + 'Clininfo.list'
	Cir_M_list = []
	JJ_M_list = []
	with open(Cir_target, 'r') as CIR_M :
		for cir_m in CIR_M:
			cir_m = cir_m.strip().split('\t')
			Cir_M_list.append(cir_m[0])
	with open(JJ_target, 'r') as JJ_M :
		for jj_m in JJ_M:
			jj_m = jj_m.strip().split('\t')
			if jj_m[2]=='HAVE':
				JJ_M_list.append(jj_m[0])
	Double_report={}
	with open(NC_report,'r') as NC:
		for nc in NC:
			nc = nc.strip().split('\t')	
			if  nc[0] != 'sample':
				Double_report[nc[0]] = [nc[2]]
	with open(Cir_report,'r') as Cir:
		for cir in Cir:
			cir = cir.strip().split('\t')
			if  cir[0] != 'sample':
				Double_report[cir[0]].append(cir[2])
	with open(JJ_report,'r') as JJ:
		for jj in JJ:
			jj = jj.strip().split('\t')
			if  jj[0] != 'sample':
				Double_report[jj[0]].append(jj[2])

	Double_Model_out = open(Double_Model,'w')
	Double_Model_out.write(format('%s\t%s\t%s\t%s\t%s\n') % ('Sample','HCC_NC','HCC_Cir','JJ_Model','Model_Type'))
	for dict_key in sorted(Double_report.keys()):
		if dict_key in JJ_M_list:
			Double_report[dict_key].append("JJ")
		elif dict_key in Cir_M_list and dict_key not in JJ_M_list:
			Double_report[dict_key].append("Cir")
		else:
			Double_report[dict_key].append("NC")
		Double_Model_out.write(format('%s\t%s\t%s\t%s\t%s\n') % (dict_key,Double_report[dict_key][0],Double_report[dict_key][1],Double_report[dict_key][2],Double_report[dict_key][3]))
	Double_Model_out.close()


def check_analysis_history(infile):
	subprocess.call(["/share/work3/yangh3857/software/miniconda2/bin/python","/share/Onc_RD_ZS/RD/LDWGS_V2/LD_WGS_V3.0.0/Check_history.py",infile])


def main():
	parser = argparse.ArgumentParser(description='Combine QC and report')
	#ingroup = parser.add_mutually_exclusive_group(required=True)
	parser.add_argument('-S', '--softdir', help='software dir path')
	parser.add_argument('-Clin', '--XQdir', help='Xuqiu dir path')
	parser.add_argument('-a', '--allfile', help='all file list')
	parser.add_argument('-CNV', '--cnvfile', help='CNVfile path')
	parser.add_argument('-f','--flowcell',help='flowcell id',required=True)
	parser.add_argument('-P', '--proJdir', help='project dir',required=True)
	args = parser.parse_args()
	
	global soft_dir
	soft_dir = args.softdir
	if soft_dir[-1] !="/":
		soft_dir+="/"
	global clininfo_dir
	clininfo_dir = args.XQdir
	if clininfo_dir[-1] !="/":
		clininfo_dir+="/"

	global projict_dir
	projict_dir = args.proJdir
	if projict_dir[-1] !="/":
		projict_dir+="/"

	FLC=args.flowcell
	all_file=args.allfile
	cnv_data=args.cnvfile

	nf_dir = projict_dir+ FLC +'/result/biomarker/NF'
	Frag_dir = projict_dir + FLC + '/result/biomarker/Fragment'
	motif_dir= projict_dir + FLC + '/result/biomarker/motif'
	bioplot_dir = projict_dir + FLC + '/result/plot/'
	global Combine_dir
	Combine_dir = projict_dir + FLC + '/result/biomarker/Comb/'
	QC_dir= projict_dir + FLC + '/result/bam/QC/'
	biomarker_dir = projict_dir + FLC + '/result/biomarker/'
	global NC_model_train
	NC_model_train = soft_dir+'Train_file/Comb_train_NC.txt'
	global Cir_model_train
	Cir_model_train = soft_dir+'Train_file/Comb_train_Cir.txt'
	global all_sample_Num
	all_sample_Num=check_data(all_file)
	N=0
	while N<1:
		motif_file=motif_dir+'/Freq/'
		motif_finish_file=check_data(motif_file)
		qc_result = check_qc_file(QC_dir,FLC)
		if motif_finish_file==all_sample_Num and qc_result is True:
			time.sleep(120)
			get_clininfo(clininfo_dir,FLC)
			CNV_combine(cnv_data,FLC)
			NF_combine(nf_dir,FLC)
			Fragment_combine(Frag_dir,FLC)
			motif_combine(motif_dir,FLC)
			Comb_NC_Model(biomarker_dir,FLC)
			Comb_Cir_Model(biomarker_dir,FLC)
			Comb_JJ_Model(biomarker_dir,FLC)
			get_report_file(Combine_dir)
			get_biomarker_info(Combine_dir)
			get_Double_Model(Combine_dir)
			QC_combine(QC_dir,FLC)
			get_use_time(projict_dir,FLC)
			biomarker_plot(Combine_dir,bioplot_dir)
			zip_scp_plot(bioplot_dir,FLC)
			get_email_data(Combine_dir,FLC)
			check_analysis_history(all_file)
			N+=2
		else:
			print ['Not all data finish']
		time.sleep(60)		
	
if __name__ == '__main__':
	main()
				
