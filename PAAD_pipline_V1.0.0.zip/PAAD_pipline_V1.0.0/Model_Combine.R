library(data.table)

args <- commandArgs(T)
soft_dir <- args[1]
run_dir <- args[2]
#setwd(run_dir)
####################Input file####################################
CNV <- fread(args[3],header=F)#CNV file
colnames(CNV) <- c("Sample","CNV_score","CNV_num")
train_gl <- args[4] #Comb_train_gl file
test_gl_out <- paste(run_dir,"/Comb_test_gl.txt",sep="")#Comb_test_gl file
LR_gl <- paste(run_dir,"/","Comb_LR_gl.txt",sep="")#Comb_LR_gl file
##################################################################

####################load Input file###############################
NF_gl <- fread(args[5],header=F) #NF_global file
colnames(NF_gl) <- c("Sample","Real","class","NF_CT_global","Cir")
Fragment <- fread(args[6],header=F) #Fragment_file
colnames(Fragment) <- c("Sample","Real","class","Fragment_CT_global","Cir")
motif <- fread(args[7],header=F)#motif_file
colnames(motif) <- c("Sample","Real","class","motif_CT_global","Cir")
NF_gl <- NF_gl[,c(1,2,4)]
Fragment <- Fragment[,c(1,4)]
motif <- motif[,c(1,4)]
#Clin_info <- fread(paste(run_dir,"/Clininfo.list",sep=""),header=F)
#colnames(Clin_info)[1] <- "Sample"
#################################################################
#######################Combine gl test file######################
all <- merge(NF_gl,Fragment,by="Sample")
all <- merge(all,motif,by="Sample")
all <- unique(all,by="Sample")
all <- all[,c(2,1,3,4,5)]
write.table(all,file=test_gl_out,quote=F,row.names=F,col.names=F,sep="\t")
#################################################################
############################# LR for global result##########
system(paste("/share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/software/python2.7.6/bin/python ",soft_dir,"LR_class.py ",train_gl," ",test_gl_out," ",LR_gl,sep=""))
system(paste("bash ",soft_dir,"remove.sh ",LR_gl,sep=""))

lr_gl <- fread(LR_gl,header=F)
colnames(lr_gl) <- c("Sample","Real","class","Comb_CT_global","Cir")
lr_gl <- lr_gl[,c(1,4)]
##########################################################################
##########################Combind all marker result#######################
finily <- merge(CNV,NF_gl,by="Sample",all.y=T)
finily[is.na(finily)] <- 0
finily <- merge(finily,Fragment,by="Sample")
finily <- merge(finily,motif,by="Sample")
finily <- merge(finily,lr_gl,by="Sample")
finily <- unique(finily,by="Sample")
#########################################################################

finily$Comb_gl <- 0
finily$CNV <- 0
finily$GZ1 <- 0
finily$GZ2 <- 0
finily$NF <- 0
finily$Fragment <- 0
finily$motif <- 0

finily[finily$CNV_score>0 & finily$CNV_score<=5]$CNV <- 1
finily[finily$CNV_score>5 & finily$CNV_score<=10]$CNV <- 2
finily[finily$CNV_score>10]$CNV <- 3

finily[finily$NF_CT_global>=0.999999 | finily$Fragment_CT_global>=0.9999 | finily$motif_CT_global>=0.9999]$GZ1 <- 1
finily[(finily$NF_CT_global>=0.999999 & finily$Fragment_CT_global>=0.9999) |(finily$NF_CT_global>=0.999999& finily$motif_CT_global>=0.9999) | (finily$Fragment_CT_global>=0.9999& finily$motif_CT_global>=0.9999)]$GZ1 <- finily[(finily$NF_CT_global>=0.999999 & finily$Fragment_CT_global>=0.9999) |(finily$NF_CT_global>=0.999999& finily$motif_CT_global>=0.9999) | (finily$Fragment_CT_global>=0.9999& finily$motif_CT_global>=0.9999)]$GZ1 +1
finily[finily$NF_CT_global>=0.999999 & finily$Fragment_CT_global>=0.9999 & finily$motif_CT_global>=0.9999]$GZ1 <- finily[finily$NF_CT_global>=0.999999 & finily$Fragment_CT_global>=0.9999 & finily$motif_CT_global>=0.9999]$GZ1 + 1

finily[finily$Comb_CT_global>=0.7681]$Comb_gl <- 1 
#finily[finily$NF_CT_global>=0.7958]$NF <- 1
finily[finily$NF_CT_global>=0.8958]$NF <- 1
finily[finily$Fragment_CT_global>=0.6412]$Fragment <- 1
finily[finily$motif_CT_global>=0.6668]$motif <- 1
finily$high_risk_count <- finily$NF + finily$Fragment + finily$motif
finily[finily$high_risk_count>=2]$GZ2 <- 1
finily[finily$high_risk_count==3]$GZ2 <- finily[finily$high_risk_count==3]$GZ2 + 1


finily$score <- finily$CNV + finily$GZ1 + finily$GZ2 + finily$Comb_gl
finily[finily$score==0]$score <- finily[finily$score==0]$Comb_CT_global
######Combine JJ info#############################
#JJ <- Clin_info[Clin_info$V3=="HAVE"]
#finily$JJ_info <- "no"
#finily[finily$Sample %in% JJ$Sample]$JJ_info <- "yes"
#finily[finily$JJ_info=="yes" & (finily$score<1 & finily$score>=0.34)]$score <- finily[finily$JJ_info=="yes" & (finily$score<1 & finily$score>=0.34)]$score + 0.66

#JJ_out <- finily[finily$JJ_info=="yes" & (finily$score<2 & finily$score>1)]
#JJ_out <- JJ_out[,c("Sample")]
#JJ_out$Marker <- "JJ Changed"
#write.table(JJ_out,file="/share/Oncology/Onc_LDWGS/all_JJ_Changed_Sample.list",quote=F,append=T,row.names=F,col.names=F,sep="\t")

#finily[finily$score>1 & finily$score<2][,c(sample(c("NF_CT_global","Fragment_CT_global","motif_CT_global","Fragment_CT_global","motif_CT_global"),1))] <- sample(seq(0.75,0.98,0.01),nrow(finily[finily$score>1 & finily$score<2]))
#finily[finily$score>1 & finily$score<2 & finily$NF_CT_global<0.2]$NF_CT_global <- finily[finily$score>1 & finily$score<2 & finily$NF_CT_global<0.2]$NF_CT_global + 0.2
#finily[finily$score>1 & finily$score<2 & finily$Fragment_CT_global<0.2]$Fragment_CT_global <- finily[finily$score>1 & finily$score<2 & finily$Fragment_CT_global<0.2]$Fragment_CT_global + 0.2
#finily[finily$score>1 & finily$score<2 & finily$motif_CT_global<0.2]$motif_CT_global <- finily[finily$score>1 & finily$score<2 & finily$motif_CT_global<0.2]$motif_CT_global + 0.2
#finily[finily$score>1 & finily$score<2]$Comb_CT_global <- finily[finily$score>1 & finily$score<2]$Comb_CT_global + 0.32
#finily[finily$score>1 & finily$score<2]$score <- 1.00
#######################################################
#finily$Comb_gl <- 0
#finily$CNV <- 0
#finily$GZ1 <- 0
#finily$GZ2 <- 0
#finily$NF <- 0
#finily$Fragment <- 0
#finily$motif <- 0

#finily[finily$CNV_score>0 & finily$CNV_score<=5]$CNV <- 1
#finily[finily$CNV_score>5 & finily$CNV_score<=10]$CNV <- 2
#finily[finily$CNV_score>10]$CNV <- 3

#finily[finily$NF_CT_global>=0.999999 | finily$Fragment_CT_global>=0.99 | finily$motif_CT_global>=0.99]$GZ1 <- 1
#finily[(finily$NF_CT_global>=0.999999 & finily$Fragment_CT_global>=0.99) |(finily$NF_CT_global>=0.999999& finily$motif_CT_global>=0.99) | (finily$Fragment_CT_global>=0.99& finily$motif_CT_global>=0.99)]$GZ1 <- finily[(finily$NF_CT_global>=0.999999 & finily$Fragment_CT_global>=0.99) |(finily$NF_CT_global>=0.999999& finily$motif_CT_global>=0.99) | (finily$Fragment_CT_global>=0.99& finily$motif_CT_global>=0.99)]$GZ1 +1
#finily[finily$NF_CT_global>=0.999999 & finily$Fragment_CT_global>=0.99 & finily$motif_CT_global>=0.99]$GZ1 <- finily[finily$NF_CT_global>=0.999999 & finily$Fragment_CT_global>=0.99 & finily$motif_CT_global>=0.99]$GZ1 + 1

#finily[finily$Comb_CT_global>=0.5775]$Comb_gl <- 1
#finily[finily$NF_CT_global>=0.7005]$NF <- 1
#finily[finily$Fragment_CT_global>=0.6317]$Fragment <- 1
#finily[finily$motif_CT_global>=0.6058]$motif <- 1
#finily$high_risk_count <- finily$NF + finily$Fragment + finily$motif
#finily[finily$high_risk_count>=2]$GZ2 <- 1
#finily[finily$high_risk_count==3]$GZ2 <- finily[finily$high_risk_count==3]$GZ2 + 1
#finily$NF <- NULL
#finily$Fragment <- NULL
#finily$motif <- NULL

#finily$score <- finily$CNV + finily$GZ1 + finily$GZ2 + finily$Comb_gl
#finily[finily$score==0]$score <- finily[finily$score==0]$Comb_CT_global

#finily$JJ_info <- NULL
#######################################################
finily$high_risk <- "no"
finily[finily$score>=1]$high_risk <- "yes"
finily$risk_level <- "低风险"
finily[finily$score>=1]$risk_level <- "高风险"
finily$Comb_all_CT <- finily$Comb_CT_global
finily <- finily[order(finily$score,finily$Comb_all_CT,decreasing=T)]
finily$rank <- 1:nrow(finily)
finily$overtake <- (nrow(finily)-finily$rank +1)/nrow(finily)
finily <- finily[order(finily$Sample)]
write.table(finily,file=paste(run_dir,"/finily_all_NC_info.txt",sep=""),quote=F,row.names=F,col.names=T,sep="\t")


#finily$Sample <- as.character(data.frame(do.call(rbind,strsplit(finily$Sample,"-V")))[,1])


bio <- finily[,c("Sample","CNV_score","NF_CT_global","Fragment_CT_global","motif_CT_global"),with=F]
all_bioinfo <- fread(paste(soft_dir,"all_Cir_biomarker_info.xls",sep=""))
all_bioinfo <- all_bioinfo[!all_bioinfo$Sample %in% bio$Sample]
bio$NF_CT_pathway <- bio$NF_CT_global
bio <- bio[,c(1,2,3,6,4,5)]
all_bioinfo <- rbind(all_bioinfo,bio)
all_bioinfo <- unique(all_bioinfo,by="Sample")
write.table(all_bioinfo,file=paste(soft_dir,"all_Cir_biomarker_info.xls",sep=""),quote=F,row.names=F,col.names=T,sep="\t")

total_Sample <- nrow(all_bioinfo)
all_bioinfo$NF_CT_global <- (all_bioinfo$NF_CT_global + all_bioinfo$NF_CT_pathway)/2
all_bioinfo <- all_bioinfo[order(all_bioinfo$NF_CT_global)]
all_bioinfo$NF_Rank <- 1:nrow(all_bioinfo)
all_bioinfo$NF_Rank <- ((total_Sample - all_bioinfo$NF_Rank +1)/total_Sample)*100
all_bioinfo$NF_Rank<- sprintf("%0.2f",all_bioinfo$NF_Rank)
all_bioinfo$NF_Rank <- paste(all_bioinfo$NF_Rank,"%",sep="")

all_bioinfo <- all_bioinfo[order(all_bioinfo$Fragment_CT_global)]
all_bioinfo$Fragment_Rank <- 1:nrow(all_bioinfo)
all_bioinfo$Fragment_Rank <- ((total_Sample - all_bioinfo$Fragment_Rank +1)/total_Sample)*100
all_bioinfo$Fragment_Rank<- sprintf("%0.2f",all_bioinfo$Fragment_Rank)
all_bioinfo$Fragment_Rank <- paste(all_bioinfo$Fragment_Rank,"%",sep="")

all_bioinfo <- all_bioinfo[order(all_bioinfo$motif_CT_global)]
all_bioinfo$motif_Rank <- 1:nrow(all_bioinfo)
all_bioinfo$motif_Rank <- ((total_Sample - all_bioinfo$motif_Rank +1)/total_Sample)*100
all_bioinfo$motif_Rank<- sprintf("%0.2f",all_bioinfo$motif_Rank)
all_bioinfo$motif_Rank <- paste(all_bioinfo$motif_Rank,"%",sep="")

bio <- all_bioinfo[all_bioinfo$Sample %in% bio$Sample]
bio <- bio[order(bio$Sample)]
bio <- bio[,c("Sample","CNV_score","NF_CT_global","NF_Rank","Fragment_CT_global","Fragment_Rank","motif_CT_global","motif_Rank"),with=F]
colnames(bio) <- c("Sample","CNV_score","NF_CT","NF_Rank","Fragment_CT","Fragment_Rank","motif_CT","motif_Rank")
bio$CNV_score <- sprintf("%0.2f",bio$CNV_score)
bio$NF_CT <- sprintf("%0.2f",bio$NF_CT)
bio$Fragment_CT <- sprintf("%0.2f",bio$Fragment_CT)
bio$motif_CT <- sprintf("%0.2f",bio$motif_CT)
write.table(bio,file=paste(run_dir,"/","biomarker_NC.xls",sep=""),quote=F,row.names=F,col.names=T,sep="\t")


finily <- finily[,c("Sample","high_risk_count","Comb_all_CT","score","high_risk","risk_level","rank","overtake"),with=F]
all_data <- fread(paste(soft_dir,"all_Sample_report.xls",sep=""))
all_data <- all_data[!all_data$Sample %in% finily$Sample]
all_data <- rbind(all_data,finily)
all_data <- unique(all_data,by="Sample")
all_data <- all_data[order(all_data$score,all_data$Comb_all_CT,decreasing=T)]
all_data$rank <- 1:nrow(all_data)
all_data$overtake <- ((nrow(all_data)-all_data$rank +1)/nrow(all_data)) *100
write.table(all_data,file=paste(soft_dir,"all_Sample_report.xls",sep=""),quote=F,row.names=F,col.names=T,sep="\t")

finily <- all_data[all_data$Sample %in% finily$Sample]
colnames(finily)[1] <- "sample"
report <- finily[,c("sample","high_risk","score","risk_level","rank","overtake"),with=F]
report$score <- round(report$score,2)
report$overtake <- sprintf("%0.2f",report$overtake)
report$overtake <- paste(report$overtake,"%",sep="")
report <- report[order(report$sample)]
report$score <- sprintf("%0.2f",report$score)
write.table(report,file=paste(run_dir,"/","report_NC.xls",sep=""),quote=F,row.names=F,col.names=T,sep="\t")

