#!/bin/bash

help_info()
{
    echo -e "NAME"  
    echo -e "\t$0"  
    echo -e "SYNOPSIS"  
    echo -e "USAGE"  
    echo -e "\tbash $0 -f <fastq dir> -n <FLC> -o <analyse dir> -x <Xuqiu file> -s <software path> -j <max run jobs>"
    echo -e "CAUTION"
    echo -e "\tEach of the parmeters above should be provided!\n"
    echo -e "\tIf you have any questions please send email to \n\tzhangqingzheng945@berryoncology.com"  
}


option()
{
    while [ -n "$1" ]
    do
    case "$1" in
    -f)
            echo "Found the -i option"
            fastqInput=$2
            ;;
    -n)
            echo "Found the -n option"
            Name=$2
            ;;
    -o)
            echo "Found the -o option"
            Output=$2
            ;;
    -x)
            echo "Found the -p option"
            Needsdir=$2
            ;;
    -s)
           echo "Found the -s option"
            Softdir=$2
            ;;
    -j)
           echo "Found the -j option"
            Jobnumbers=$2
            ;;
     *)
            echo "$1 is not an valid option"
            help_info
            exit -1
            ;;
    esac
    shift 2
    done
}


if [ $# -lt 6 ];then
      help_info
      exit -2
else
      option $*
        fi


if [ ${fastqInput: -1} != "/" ];then
fastqInput=${fastqInput}/
fi

if [ ${Output: -1} != "/" ];then
Output=${Output}/
fi

if [ ${Softdir: -1} != "/" ];then
Softdir=${Softdir}/
fi


mkdir -p ${Output}${Name}/result
/share/work3/yangh3857/software/miniconda2/bin/python ${Softdir}make_input.py -f ${fastqInput} -name ${Name} -Clin ${Needsdir} -i ${Output}${Name}
echo "${Softdir}LDWGSrun  -i Input.txt -o ${Output}${Name}/result" > ${Output}${Name}/run.sh
echo "/share/work3/yangh3857/software/miniconda2/bin/python ${Softdir}/Combine_QC_class_result.py  -S ${Softdir} -Clin ${Needsdir} -a ${Output}${Name}/Input.txt -CNV ${Output}${Name}/result/biomarker/CNV/ -f ${Name} -P ${Output} &" >> ${Output}${Name}/run.sh
cd ${Output}${Name}/
bash ${Output}${Name}/run.sh >> ${Output}${Name}/yunxing.out
bash ${Output}${Name}/ln.sh
cp ${Softdir}CNV/runCNV.sh  ${Output}${Name}/result/biomarker/CNV/
nohup make -j ${Jobnumbers} -f ${Output}${Name}/result/.result.job -k >> ${Output}${Name}/yunxing.out &
cd  ${Output}${Name}/result/biomarker/CNV/
nohup bash runCNV.sh  ${Output}${Name}/result/biomarker/CNV ${Softdir} &

