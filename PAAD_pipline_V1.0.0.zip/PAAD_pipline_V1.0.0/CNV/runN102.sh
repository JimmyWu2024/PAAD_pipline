Rscript /share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/software/IT_map/detectcnv.r MAP/data cnv_N102 5 5 /share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/ProJect/CNV/CNV_T7/insref_MIX
