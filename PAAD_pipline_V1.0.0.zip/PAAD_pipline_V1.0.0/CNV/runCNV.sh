dir=$1
mkdir -p data MAP

qsub -cwd -l vf=50g -q oncrd.q -sync y -N MAP /share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/software/IT_map/MAPPING.sh $dir/data $dir/MAP

qsub -cwd -l vf=15g -q oncrd.q -sync y /share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/software/IT_map/runN102.sh
perl /share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/software/IT_map/convertCallResult_2.pl -i cnv_N102/callcnv/*.txt > cnv_N102.txt

mkdir -p cnv_N102/ann && cd cnv_N102/ann

perl /share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/software/IT_map/Segs2Vcf.pl -i ../../cnv_N102.txt -d ./
sh /share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/software/IT_map/ann.sh > cmd.sh
vn=$(ls *.cnv.vcf| wc -l)
if [ $vn -eq 0 ]
then
	touch score
else
	qsub -cwd -l vf=10g -q oncrd.q -sync y -N ann cmd.sh
	cat *.score > score
fi
cat *.score > score
perl /share/Onc_RD_ZS/RD/BYZ2017022/zhangqz/software/IT_map/addZoneSample.pl -i score -s ../../MAP/data/ > cnv.score.txt
cp cnv.score.txt ../../
cd ../../
rm -rf MAP/data/*.unique_reads

